## 2.1.1
- Improve pub static analysis
- Add web & windows platform for launching example app

## 2.1.0
- Added new optional field: extraCountBorderColor to set the color of circular extra count
- Refactored internal package code
- Migrate example app to v2 Android embedding

This update was possible because of [Siarhei Alikhver](https://github.com/solikhver)

## 2.0.1

- Add documentation to the package
- Bump the minimum dart sdk of the example app to 2.12.0

## 2.0.0

- Migrate package to null-safety

## 1.1.0

- Better customisation

## 1.0.1

- Example App updated

## 1.0.0 - First Release

- Package created.
